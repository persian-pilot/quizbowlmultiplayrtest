// Home page: create a game, join by code, or pick a public one.
(() => {
  const nameInput = $('nameInput');
  const err = $('homeErr');
  nameInput.value = getName();

  function showErr(msg) { err.textContent = msg || ''; }

  function needName() {
    const n = nameInput.value.trim();
    if (!n) { showErr('Please enter a display name first.'); nameInput.focus(); return null; }
    setName(n);
    showErr('');
    return n;
  }

  async function createGame(isPublic) {
    if (!needName()) return;
    try {
      const res = await fetch('/api/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ public: isPublic }),
      });
      const data = await res.json();
      if (!res.ok) return showErr(data.error || 'Could not create a game.');
      location.href = '/game/' + data.code;
    } catch {
      showErr('Could not reach the server.');
    }
  }

  async function joinCode(code) {
    if (!needName()) return;
    code = String(code || '').trim().toUpperCase();
    if (code.length !== 5) return showErr('Room codes are 5 characters.');
    try {
      const res = await fetch('/api/games/' + encodeURIComponent(code));
      const data = await res.json();
      if (!res.ok) return showErr(data.error || 'Game not found.');
      if (!data.joinable) return showErr('That game has already started or is full.');
      location.href = '/game/' + data.code;
    } catch {
      showErr('Could not reach the server.');
    }
  }

  $('createPublic').onclick = () => createGame(true);
  $('createPrivate').onclick = () => createGame(false);
  $('joinBtn').onclick = () => joinCode($('codeInput').value);
  $('codeInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') joinCode(e.target.value); });
  nameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') createGame(true); });

  async function refreshList() {
    const list = $('publicList');
    try {
      const games = await (await fetch('/api/games')).json();
      if (!games.length) {
        list.replaceChildren(h('div', { class: 'empty' }, 'No open public games right now — create one!'));
        return;
      }
      list.replaceChildren(...games.map((g) =>
        h('div', { class: 'game-item' },
          h('div', null,
            h('b', null, `${g.host}'s game `),
            h('span', { class: 'badge code' }, g.code),
            h('div', { class: 'meta' }, `${g.players}/${g.max} players`)),
          h('button', { class: 'btn small primary', onclick: () => joinCode(g.code) }, 'Join'))
      ));
    } catch {
      list.replaceChildren(h('div', { class: 'empty' }, 'Could not load games.'));
    }
  }
  refreshList();
  setInterval(refreshList, 3000);
})();
