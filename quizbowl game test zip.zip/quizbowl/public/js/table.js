// The animated table. Seats glide (CSS transitions on left/top) as players
// move from the lobby ring to their team's side of the table.
window.Table = (() => {
  const seatsEl = document.getElementById('seats');
  const seats = new Map(); // playerId -> element
  const prevScore = new Map(); // playerId -> last score (for floating +10 / -5)
  const RX = 42; // ellipse radii in % of the table box
  const RY = 37;

  const onEllipse = (deg) => {
    const a = (deg * Math.PI) / 180;
    return { x: 50 + RX * Math.cos(a), y: 50 + RY * Math.sin(a) };
  };

  // Work out where every seat should be.
  function layout(players) {
    const spots = new Map();
    const anyTeams = players.some((p) => p.team !== null);

    const unassigned = players.filter((p) => p.team === null);
    if (!anyTeams) {
      // lobby: everyone around the whole table
      unassigned.forEach((p, i) => spots.set(p.id, onEllipse(-90 + (i * 360) / unassigned.length)));
    } else {
      // draft pool waits on a bench along the bottom
      unassigned.forEach((p, i) => {
        spots.set(p.id, { x: 50 + (i - (unassigned.length - 1) / 2) * 14, y: 92 });
      });
    }

    for (const team of [0, 1]) {
      const mates = players
        .filter((p) => p.team === team)
        .sort((a, b) => Number(b.isCaptain) - Number(a.isCaptain));
      const n = mates.length;
      const side = team === 0 ? 180 : 0; // Red on the left, Blue on the right
      mates.forEach((p, i) => {
        const idx = team === 0 ? n - 1 - i : i; // captain sits at the top on both sides
        spots.set(p.id, onEllipse(side + (idx - (n - 1) / 2) * 38));
      });
    }
    return spots;
  }

  function makeSeat(spot) {
    const el = document.createElement('div');
    el.className = 'seat';
    el.style.left = spot.x + '%';
    el.style.top = spot.y + '%';
    el.innerHTML =
      '<div class="bubble">BUZZ!</div>' +
      '<div class="avatar"><span class="crown">👑</span><span class="ini"></span></div>' +
      '<div class="nm"></div><div class="pts"></div>';
    seatsEl.appendChild(el);
    return el;
  }

  function floater(el, delta) {
    const f = document.createElement('div');
    f.className = 'floater ' + (delta > 0 ? 'pos' : 'neg');
    f.textContent = (delta > 0 ? '+' : '') + delta;
    el.appendChild(f);
    setTimeout(() => f.remove(), 1600);
  }

  function render(state, meId) {
    const spots = layout(state.players);
    const seen = new Set();

    for (const p of state.players) {
      seen.add(p.id);
      const spot = spots.get(p.id);
      let el = seats.get(p.id);
      if (!el) {
        el = makeSeat(spot);
        seats.set(p.id, el);
      }
      el.style.left = spot.x + '%';
      el.style.top = spot.y + '%';

      el.className = 'seat' +
        (p.team !== null ? ` team-${p.team}` : '') +
        (p.isCaptain ? ' captain' : '') +
        (p.buzzing ? ' buzzing' : '') +
        (p.lockedOut ? ' locked' : '') +
        (!p.connected ? ' offline' : '') +
        (p.id === meId ? ' me' : '');

      el.querySelector('.ini').textContent = p.name.slice(0, 2).toUpperCase();
      el.querySelector('.nm').textContent = p.name + (p.id === meId ? ' (you)' : '');
      el.querySelector('.pts').textContent =
        p.team !== null ? `${p.score} pts` : p.isHost ? 'host' : '';

      if (prevScore.has(p.id) && prevScore.get(p.id) !== p.score) floater(el, p.score - prevScore.get(p.id));
      prevScore.set(p.id, p.score);
    }

    // anyone who left fades out
    for (const [id, el] of seats) {
      if (!seen.has(id)) {
        el.classList.add('leaving');
        setTimeout(() => el.remove(), 450);
        seats.delete(id);
        prevScore.delete(id);
      }
    }
  }

  return { render };
})();
