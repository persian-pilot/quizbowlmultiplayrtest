// Game page: connects to the server, keeps the latest state, and renders it.
(() => {
  const code = location.pathname.split('/').filter(Boolean).pop().toUpperCase();
  const me = getPlayerId();
  const socket = io();

  let state = null;
  let clockOffset = 0; // serverTime - clientTime, so timers match the server
  let wasAnswering = false;

  $('roomCode').textContent = code;
  $('modalCode').textContent = code;
  $('inviteInput').value = `${location.origin}/game/${code}`;

  // ---------------------------------------------------------------- joining
  function join() {
    const name = getName();
    if (!name) { $('nameModal').hidden = false; $('modalName').focus(); return; }
    socket.emit('join', { code, playerId: me, name }, (res) => {
      if (!res || !res.ok) {
        $('fatalMsg').textContent = (res && res.error) || 'Could not join.';
        $('fatal').hidden = false;
        return;
      }
      $('nameModal').hidden = true;
    });
  }

  $('nameForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const n = $('modalName').value.trim();
    if (!n) return;
    setName(n);
    join();
  });

  socket.on('connect', () => { $('conn').hidden = true; join(); });
  socket.on('disconnect', () => { $('conn').hidden = false; });

  function copyInvite() {
    const link = `${location.origin}/game/${code}`;
    (navigator.clipboard ? navigator.clipboard.writeText(link) : Promise.reject())
      .then(() => toast('Invite link copied!'))
      .catch(() => { $('inviteInput').select(); toast('Press Ctrl+C to copy the link.'); });
  }
  $('copyLink').onclick = copyInvite;
  $('copyLink2').onclick = copyInvite;

  // ----------------------------------------------------------- server events
  socket.on('state', (s) => {
    state = s;
    clockOffset = s.serverTime - Date.now();
    render();
  });

  socket.on('tossup:text', (d) => {
    if (state && state.tossup && state.tossup.number === d.number) {
      state.tossup.text = d.text;
      renderTossupText();
    }
  });

  socket.on('chat:history', (list) => Chat.setHistory(list, me));
  socket.on('chat:msg', (m) => Chat.add(m, me));
  socket.on('notice', (n) => toast(n.text));

  // ----------------------------------------------------------- user actions
  Chat.onSend((text) => socket.emit('chat', { text }));
  $('startBtn').onclick = () => socket.emit('start');

  function buzz() {
    const meP = myPlayer();
    if (!state || !state.tossup || !meP) return;
    const t = state.tossup;
    if ((t.status === 'reading' || t.status === 'open') && meP.team !== null && !meP.lockedOut) {
      socket.emit('buzz');
    }
  }
  $('buzzBtn').onclick = buzz;
  document.addEventListener('keydown', (e) => {
    if (e.code !== 'Space') return;
    const tag = document.activeElement && document.activeElement.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    e.preventDefault();
    buzz();
  });

  let answerSent = false;
  $('answerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const text = $('answerInput').value.trim();
    if (!text || answerSent) return;
    answerSent = true;
    socket.emit('tossup:answer', { text });
  });

  // --------------------------------------------------------------- rendering
  const myPlayer = () => state && state.players.find((p) => p.id === me);
  const teamName = (t) => state.teamNames[t];
  const nameOf = (id) => { const p = state.players.find((x) => x.id === id); return p ? p.name : '?'; };

  function animateNumber(el, to) {
    const from = parseInt(el.textContent, 10) || 0;
    if (from === to) return;
    const start = performance.now();
    el.classList.remove('bump');
    void el.offsetWidth; // restart animation
    el.classList.add('bump');
    (function step(now) {
      const t = Math.min(1, (now - start) / 600);
      el.textContent = Math.round(from + (to - from) * t);
      if (t < 1) requestAnimationFrame(step);
    })(start);
  }

  function renderScoreboard(s) {
    for (const t of [0, 1]) {
      $('tname' + t).textContent = s.teamNames[t];
      animateNumber($('score' + t), s.scores[t]);
      const cap = s.players.find((p) => p.team === t && p.isCaptain);
      $('cap' + t).textContent = cap ? `Captain: ${cap.name}` : '';
    }
    $('roundInfo').textContent = s.totalRounds ? `${Math.max(1, s.round)} / ${s.totalRounds}` : '–';

    let active = null;
    if (s.phase === 'bonus' && s.bonus) active = s.bonus.team;
    else if (s.phase === 'tossup' && s.tossup && s.tossup.buzzer) active = s.players.find((p) => p.id === s.tossup.buzzer).team;
    else if (s.phase === 'draft' && s.draft && s.draft.turnTeam !== null) active = s.draft.turnTeam;
    $('box0').classList.toggle('active', active === 0);
    $('box1').classList.toggle('active', active === 1);
    $('felt').dataset.glow = active !== null ? String(active) : s.phase === 'finished' ? 'gold' : '';
  }

  function renderCenter(s) {
    let title = '';
    let sub = '';
    const here = s.players.filter((p) => p.connected).length;
    switch (s.phase) {
      case 'lobby':
        title = 'Waiting for players';
        sub = `${here}/${s.maxPlayers} at the table`;
        break;
      case 'draft':
        title = 'Captain draft';
        sub = s.draft && s.draft.done ? 'Teams are set!' : s.draft ? `${teamName(s.draft.turnTeam)} is picking` : '';
        break;
      case 'tossup':
        title = `Tossup ${s.tossup.number} of ${s.totalRounds}`;
        sub = s.tossup.status === 'answering' ? `${nameOf(s.tossup.buzzer)} is answering…` : s.tossup.category;
        break;
      case 'bonus':
        title = `${teamName(s.bonus.team)} bonus`;
        sub = `Part ${s.bonus.partIndex + 1} of ${s.bonus.partCount}`;
        break;
      case 'finished':
        title = s.winner === null ? "It's a tie!" : `${teamName(s.winner)} wins!`;
        sub = `${s.scores[0]} – ${s.scores[1]}`;
        break;
    }
    $('centerTitle').textContent = title;
    $('centerSub').textContent = sub;
  }

  function renderTossupText() {
    const t = state.tossup;
    const el = $('tuText');
    el.textContent = t.text;
    el.classList.toggle('cursor', !t.done && t.status === 'reading');
  }

  function show(id, on) { $(id).hidden = !on; }

  function renderPanels(s, meP) {
    show('lobbyPanel', s.phase === 'lobby');
    show('draftPanel', s.phase === 'draft');
    show('tossupPanel', s.phase === 'tossup');
    show('bonusPanel', s.phase === 'bonus');
    show('finishedPanel', s.phase === 'finished');

    if (s.phase === 'lobby') {
      const here = s.players.filter((p) => p.connected).length;
      $('lobbyCount').textContent = s.players.length;
      $('lobbyMax').textContent = s.maxPlayers;
      const isHost = s.hostId === me;
      show('startBtn', isHost);
      $('startBtn').disabled = here < s.minPlayers;
      $('lobbyNote').textContent = isHost
        ? (here < s.minPlayers ? `Need at least ${s.minPlayers} players to start.` : 'You are the host — start whenever everyone is here.')
        : 'Waiting for the host to start the game…';
      $('visBadge').textContent = s.isPublic ? 'Public' : 'Private';
    }

    if (s.phase === 'draft') {
      const d = s.draft;
      const pool = s.players.filter((p) => p.team === null);
      const myTurn = !!(meP && d && !d.done && meP.isCaptain && meP.team === d.turnTeam);
      if (d.done) $('draftTurn').textContent = 'Draft complete! The game is starting…';
      else {
        const cap = s.players.find((p) => p.isCaptain && p.team === d.turnTeam);
        $('draftTurn').textContent = myTurn
          ? 'Your pick! Choose a teammate:'
          : `${teamName(d.turnTeam)} captain ${cap ? cap.name : ''} is choosing…`;
      }
      $('poolList').replaceChildren(...pool.map((p) =>
        h('button', {
          class: 'btn', disabled: !myTurn,
          onclick: () => socket.emit('draft:pick', { targetId: p.id }),
        }, p.name)));
    }

    if (s.phase === 'tossup') renderTossupPanel(s, meP);
    if (s.phase === 'bonus') renderBonusPanel(s, meP);

    if (s.phase === 'finished') {
      $('finalText').textContent = s.winner === null ? "It's a tie!" : `${teamName(s.winner)} wins!`;
      const top = [...s.players].sort((a, b) => b.score - a.score)[0];
      $('finalScores').textContent =
        `${teamName(0)} ${s.scores[0]} – ${s.scores[1]} ${teamName(1)}` + (top ? ` · Top scorer: ${top.name} (${top.score})` : '');
    }
  }

  function renderTossupPanel(s, meP) {
    const t = s.tossup;
    $('tuCat').textContent = `Tossup ${t.number} · ${t.category}`;
    renderTossupText();

    const iAmBuzzer = t.buzzer === me;
    let status = '';
    if (t.status === 'reading') status = 'Reading… buzz in at any time! (Buzzing early and missing costs −5.)';
    else if (t.status === 'open') status = 'Question finished — last chance to buzz!';
    else if (t.status === 'answering') {
      status = iAmBuzzer ? 'You buzzed! Type your answer — you have 10 seconds.' : `${nameOf(t.buzzer)} buzzed in and is answering…`;
    } else if (t.status === 'reveal') {
      const r = t.result;
      status = r && r.correct
        ? `✔ ${nameOf(r.playerId)} got it for ${teamName(r.team)}! Answer: ${t.answer}`
        : `Nobody got it. Answer: ${t.answer}`;
    }
    const st = $('tuStatus');
    st.textContent = status;
    st.className = 'statusline' + (t.status === 'reveal' ? (t.result && t.result.correct ? ' good' : ' bad') : '');

    // buzz button
    const canBuzz = !!meP && meP.team !== null && !meP.lockedOut && (t.status === 'reading' || t.status === 'open');
    const bb = $('buzzBtn');
    bb.disabled = !canBuzz;
    bb.textContent = meP && meP.lockedOut ? 'LOCKED OUT' : 'BUZZ (Space)';
    show('buzzBtn', !iAmBuzzer);

    // answer box for the player who buzzed
    const answering = t.status === 'answering' && iAmBuzzer;
    show('answerForm', answering);
    if (answering && !wasAnswering) {
      answerSent = false;
      $('answerInput').value = '';
      $('answerInput').focus();
    }
    wasAnswering = answering;
  }

  function renderBonusPanel(s, meP) {
    const b = s.bonus;
    $('bnCat').textContent = `${teamName(b.team)} bonus · ${b.category}`;
    $('bnLead').textContent = b.leadin;
    $('bnPrompt').textContent = b.prompt;
    const dots = [];
    for (let i = 0; i < b.partCount; i++) {
      const r = b.results[i];
      const cls = 'dot' + (r === true ? ' ok' : r === false ? ' no' : '') + (i === b.partIndex ? ' cur' : '');
      dots.push(h('span', { class: cls }, r === true ? '✓' : r === false ? '✗' : i + 1));
    }
    $('bnDots').replaceChildren(...dots);

    const onTeam = !!meP && meP.team === b.team;
    const capName = nameOf(b.captainId);
    let status;
    if (b.status === 'reveal') {
      status = b.lastCorrect
        ? `✔ Correct! The answer was ${b.answer}.`
        : `✘ ${b.lastAnswer === null ? "Time's up." : 'Incorrect.'} The answer was ${b.answer}.`;
    } else if (!onTeam) {
      status = `Shh! ${teamName(b.team)} is conferring. Their chat is private.`;
    } else if (b.captainId === me) {
      status = 'You are the captain! Confer with your team, then type:  Answer: your answer  in chat.';
    } else {
      status = `Confer with your team in chat. Captain ${capName} gives the final answer with  Answer: …`;
    }
    const st = $('bnStatus');
    st.textContent = status;
    st.className = 'statusline' + (b.status === 'reveal' ? (b.lastCorrect ? ' good' : ' bad') : '');
  }

  function renderChatMode(s, meP) {
    const c = s.chat;
    if (c.mode === 'all') {
      Chat.setMode({ enabled: !!meP, placeholder: 'Message everyone…', label: '● Open to all', kind: 'open' });
    } else if (c.mode === 'team') {
      if (meP && meP.team === c.team) {
        const cap = s.bonus && s.bonus.captainId === me;
        Chat.setMode({
          enabled: true,
          placeholder: cap ? 'Captain: type  Answer: your answer' : 'Confer with your team…',
          label: '● Team chat', kind: 'team',
        });
      } else {
        Chat.setMode({ enabled: false, placeholder: 'Locked — the other team is conferring', label: '● Locked', kind: 'locked' });
      }
    } else {
      Chat.setMode({ enabled: false, placeholder: c.reason, label: '● Locked', kind: 'locked' });
    }
  }

  function render() {
    const s = state;
    const meP = myPlayer();
    $('visBadge').textContent = s.isPublic ? 'Public' : 'Private';
    renderScoreboard(s);
    Table.render(s, me);
    renderCenter(s);
    renderPanels(s, meP);
    renderChatMode(s, meP);
  }

  // ------------------------------------------------------------ countdown UI
  setInterval(() => {
    if (!state) return;
    const ring = $('clockRing');
    const c = state.clock;
    const bars = document.querySelectorAll('.js-bar');
    if (!c) {
      ring.classList.add('idle');
      ring.style.setProperty('--p', 0);
      $('clockNum').textContent = '';
      bars.forEach((b) => { b.style.width = '0%'; });
      return;
    }
    const left = Math.max(0, c.deadline - (Date.now() + clockOffset));
    const pct = Math.min(100, (left / c.duration) * 100);
    ring.classList.remove('idle');
    ring.dataset.kind = c.kind;
    ring.style.setProperty('--p', pct);
    $('clockNum').textContent = Math.ceil(left / 1000);
    bars.forEach((b) => { b.style.width = pct + '%'; });
  }, 100);
})();
