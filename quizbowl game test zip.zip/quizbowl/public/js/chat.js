// Chat panel. The SERVER decides who may talk and to whom (all / team / locked);
// this file only renders messages and enables/disables the input.
window.Chat = (() => {
  const box = document.getElementById('chatMessages');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const send = document.getElementById('chatSend');
  const modeEl = document.getElementById('chatMode');
  let onSend = () => {};

  function render(m, meId) {
    const teamCls = m.team === 0 ? 'team-0' : m.team === 1 ? 'team-1' : 'team-n';
    const el = document.createElement('div');
    el.className = `msg kind-${m.kind} ${teamCls}`;
    if (m.kind === 'system') {
      el.textContent = m.text;
      return el;
    }
    if (m.channel === 'team') {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = 'TEAM';
      el.append(chip);
    }
    const who = document.createElement('span');
    who.className = 'who';
    who.textContent = m.name + (m.from === meId ? ' (you)' : '') + ':';
    el.append(who, document.createTextNode(m.text)); // textContent only — no HTML injection
    return el;
  }

  function add(m, meId) {
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    box.append(render(m, meId));
    while (box.children.length > 200) box.firstChild.remove();
    if (nearBottom || m.from === meId) box.scrollTop = box.scrollHeight;
  }

  function setHistory(list, meId) {
    box.replaceChildren(...list.map((m) => render(m, meId)));
    box.scrollTop = box.scrollHeight;
  }

  // { enabled, placeholder, label, kind: 'open' | 'team' | 'locked' }
  function setMode(cfg) {
    input.disabled = !cfg.enabled;
    send.disabled = !cfg.enabled;
    input.placeholder = cfg.placeholder;
    modeEl.textContent = cfg.label;
    modeEl.className = cfg.kind;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text || input.disabled) return;
    onSend(text);
    input.value = '';
  });

  return {
    add,
    setHistory,
    setMode,
    onSend: (fn) => { onSend = fn; },
    focus: () => input.focus(),
  };
})();
