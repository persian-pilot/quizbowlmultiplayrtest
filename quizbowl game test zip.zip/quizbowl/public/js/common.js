// Small helpers shared by both pages.
const $ = (id) => document.getElementById(id);

// h('div', {class:'x', onclick: fn}, 'text', childEl) — builds DOM safely (no innerHTML)
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, '');
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

// Identity is per browser TAB (sessionStorage) so you can test with several tabs.
// Refreshing a tab keeps you in your game; closing the tab forgets you.
function getPlayerId() {
  let id = sessionStorage.getItem('qb_pid');
  if (!id) {
    id = (window.crypto && crypto.randomUUID)
      ? crypto.randomUUID()
      : 'p-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    sessionStorage.setItem('qb_pid', id);
  }
  return id;
}

function getName() { return (localStorage.getItem('qb_name') || '').trim(); }
function setName(n) { localStorage.setItem('qb_name', String(n).trim().slice(0, 16)); }

let toastTimer;
function toast(msg) {
  let el = $('toast');
  if (!el) { el = h('div', { id: 'toast' }); document.body.append(el); }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}
