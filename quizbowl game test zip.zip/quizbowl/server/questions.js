// PLACEHOLDER QUESTIONS — replace these with your real packet later.
//
// Tossup format: { category, text, answer, accept: [alternate answers] }
//   - write clues hardest-first, ending with a "For 10 points, ..." giveaway
// Bonus format:  { category, leadin, parts: [{ prompt, answer, accept: [] }, ...] }
//
// Answers are matched loosely (case, punctuation, "the/a/an" and small typos are
// ignored) — see answerCheck.js. Put any other acceptable answers in `accept`.

const TOSSUPS = [
  {
    category: 'Geography',
    text: 'The Catacombs beneath this city hold the remains of millions of people, and its Left Bank is home to the Sorbonne. A world\'s fair in 1889 led to the construction here of a wrought-iron tower by Gustave Eiffel. The Louvre, a former royal palace, sits along the Seine in this city. For 10 points, name this capital of France.',
    answer: 'Paris',
    accept: ['City of Paris'],
  },
  {
    category: 'Biology',
    text: 'In C4 plants, the Hatch-Slack pathway concentrates carbon dioxide for this process. Its light-dependent reactions take place in the thylakoid membranes, while the Calvin cycle takes place in the stroma. Chlorophyll absorbs light to drive this process, which releases oxygen as a byproduct. For 10 points, name this process by which plants turn sunlight, water, and carbon dioxide into sugar.',
    answer: 'Photosynthesis',
    accept: [],
  },
  {
    category: 'Literature',
    text: 'This author\'s sonnets address a Fair Youth and a Dark Lady. He wrote of the magician Prospero in The Tempest and of a Danish prince who contemplates the skull of the jester Yorick. He was a shareholder in the Globe Theatre. For 10 points, name this English playwright of Hamlet and Macbeth.',
    answer: 'William Shakespeare',
    accept: ['Shakespeare'],
  },
  {
    category: 'Geography',
    text: 'The Ring of Fire, a belt of volcanoes and earthquake zones, surrounds this ocean. Its deepest point is the Challenger Deep in the Mariana Trench. Ferdinand Magellan\'s expedition gave it a name meaning "peaceful." Hawaii, Fiji, and Japan all lie in this ocean. For 10 points, name this largest and deepest ocean on Earth.',
    answer: 'Pacific Ocean',
    accept: ['Pacific'],
  },
  {
    category: 'Mathematics',
    text: 'President James Garfield published a proof of this theorem, and Fermat\'s Last Theorem generalizes its equation to higher powers. Integer solutions to it are called triples, such as 3, 4, 5. It states that a squared plus b squared equals c squared in a right triangle. For 10 points, name this theorem named for a Greek philosopher.',
    answer: 'Pythagorean theorem',
    accept: ['Pythagoras theorem', 'Pythagoras\' theorem', 'Pythagoras'],
  },
  {
    category: 'Music',
    text: 'This composer left a Requiem in D minor unfinished at his death in 1791, and it was completed by Franz Sussmayr. He wrote the operas The Marriage of Figaro and The Magic Flute, as well as a Symphony No. 41 nicknamed "Jupiter." Born in Salzburg, he was a child prodigy. For 10 points, name this Austrian composer of Eine kleine Nachtmusik.',
    answer: 'Wolfgang Amadeus Mozart',
    accept: ['Mozart'],
  },
  {
    category: 'Science',
    text: 'Valles Marineris, one of the largest canyons in the solar system, is found on this planet, as is Olympus Mons, the tallest known volcano. Its two small moons are Phobos and Deimos, and the rovers Curiosity and Perseverance have explored its surface. Iron oxide gives it a reddish color. For 10 points, name this fourth planet from the Sun.',
    answer: 'Mars',
    accept: [],
  },
  {
    category: 'American History',
    text: 'In 1863, this president gave a short speech at a Pennsylvania battlefield that began "Four score and seven years ago." He issued the Emancipation Proclamation and promoted Ulysses S. Grant to lead the Union armies. He was shot at Ford\'s Theatre by John Wilkes Booth. For 10 points, name this sixteenth U.S. president.',
    answer: 'Abraham Lincoln',
    accept: ['Lincoln'],
  },
  {
    category: 'Geography',
    text: 'The annual flooding of this river deposited the fertile silt that supported farming in ancient Egypt. Its two main branches, the White and the Blue, meet at Khartoum. It flows northward past the Aswan High Dam and empties into the Mediterranean through a large delta. For 10 points, name this river, one of the longest in the world.',
    answer: 'Nile River',
    accept: ['Nile', 'The Nile'],
  },
  {
    category: 'Literature',
    text: 'Characters in this novel include the narrator Nick Carraway, the golfer Jordan Baker, and Tom and Daisy Buchanan. A green light at the end of a dock and the "Valley of Ashes" are important symbols in it. It is set on Long Island in the summer of 1922. For 10 points, name this F. Scott Fitzgerald novel about the mysterious millionaire Jay Gatsby.',
    answer: 'The Great Gatsby',
    accept: ['Great Gatsby'],
  },
  {
    category: 'Biology',
    text: 'Rosalind Franklin\'s X-ray diffraction image, known as Photo 51, helped reveal the structure of this molecule. Its rungs are made of the base pairs adenine-thymine and guanine-cytosine. James Watson and Francis Crick proposed its double-helix shape in 1953. For 10 points, name this molecule that carries genetic information.',
    answer: 'DNA',
    accept: ['Deoxyribonucleic acid'],
  },
  {
    category: 'Art',
    text: 'This artist sketched the Vitruvian Man and kept thousands of pages of notebooks written in mirror script. He painted The Last Supper in Milan and a portrait of Lisa Gherardini. He designed flying machines centuries before the airplane. For 10 points, name this Italian Renaissance polymath who painted the Mona Lisa.',
    answer: 'Leonardo da Vinci',
    accept: ['Leonardo', 'da Vinci', 'Davinci'],
  },
];

const BONUSES = [
  {
    category: 'Geography',
    leadin: 'Name these world capitals.',
    parts: [
      { prompt: 'This city is the capital of Japan.', answer: 'Tokyo', accept: [] },
      { prompt: 'This planned city, not Sydney or Melbourne, is the capital of Australia.', answer: 'Canberra', accept: [] },
      { prompt: 'This city on the Ottawa River is the capital of Canada.', answer: 'Ottawa', accept: [] },
    ],
  },
  {
    category: 'Chemistry',
    leadin: 'Answer these questions about chemical elements.',
    parts: [
      { prompt: 'This element with the symbol Au has long been used in jewelry and coins.', answer: 'Gold', accept: [] },
      { prompt: 'This metal with the symbol Fe is the main component of steel.', answer: 'Iron', accept: [] },
      { prompt: 'This lightest and most abundant element in the universe has atomic number 1.', answer: 'Hydrogen', accept: [] },
    ],
  },
  {
    category: 'Literature',
    leadin: 'Name these authors.',
    parts: [
      { prompt: 'This author wrote Animal Farm and Nineteen Eighty-Four.', answer: 'George Orwell', accept: ['Orwell'] },
      { prompt: 'This author wrote Pride and Prejudice and Emma.', answer: 'Jane Austen', accept: ['Austen'] },
      { prompt: 'This author wrote Moby-Dick.', answer: 'Herman Melville', accept: ['Melville'] },
    ],
  },
  {
    category: 'American History',
    leadin: 'Answer these questions about early American history.',
    parts: [
      { prompt: 'Name the first president of the United States.', answer: 'George Washington', accept: ['Washington'] },
      { prompt: 'This man was the principal author of the Declaration of Independence.', answer: 'Thomas Jefferson', accept: ['Jefferson'] },
      { prompt: 'The Pilgrims sailed to Plymouth in 1620 aboard this ship.', answer: 'Mayflower', accept: ['The Mayflower'] },
    ],
  },
  {
    category: 'Mathematics',
    leadin: 'Answer these quick math questions.',
    parts: [
      { prompt: 'How many sides does a hexagon have?', answer: '6', accept: ['six'] },
      { prompt: 'What is the square root of 144?', answer: '12', accept: ['twelve'] },
      { prompt: 'What is the only even prime number?', answer: '2', accept: ['two'] },
    ],
  },
  {
    category: 'Fine Arts',
    leadin: 'Answer these questions about the arts.',
    parts: [
      { prompt: 'This Dutch painter created The Starry Night.', answer: 'Vincent van Gogh', accept: ['Van Gogh', 'Gogh'] },
      { prompt: 'This composer wrote the Ninth Symphony, which ends with the "Ode to Joy."', answer: 'Ludwig van Beethoven', accept: ['Beethoven'] },
      { prompt: 'This instrument typically has 88 keys.', answer: 'Piano', accept: ['Pianoforte'] },
    ],
  },
];

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Returns `n` items without repeats (reshuffles and cycles only if n > pool size).
function pick(pool, n) {
  const out = [];
  while (out.length < n) out.push(...shuffle(pool));
  return out.slice(0, n);
}

module.exports = {
  pickTossups: (n) => pick(TOSSUPS, Math.min(n, TOSSUPS.length)),
  pickBonuses: (n) => pick(BONUSES, n),
  TOSSUPS,
  BONUSES,
};
