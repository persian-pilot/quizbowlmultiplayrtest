// Loose answer matching: ignores case, accents, punctuation and a/an/the,
// and forgives tiny typos on longer answers.

function normalize(s) {
  return String(s ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\b(the|a|an)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return dp[a.length][b.length];
}

function matches(guess, target) {
  if (!guess || !target) return false;
  if (guess === target) return true;
  const len = target.length;
  const maxEdits = len >= 9 ? 2 : len >= 5 ? 1 : 0;
  if (!maxEdits) return false;
  if (Math.abs(guess.length - len) > maxEdits) return false;
  return levenshtein(guess, target) <= maxEdits;
}

// `item` is a tossup or a bonus part: { answer, accept: [] }
function isCorrect(input, item) {
  const guess = normalize(input);
  if (!guess) return false;
  const targets = [item.answer, ...(item.accept || [])].map(normalize);
  return targets.some((t) => matches(guess, t));
}

module.exports = { isCorrect, normalize };
