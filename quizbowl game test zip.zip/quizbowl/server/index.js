'use strict';
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const C = require('./config');
const GameManager = require('./GameManager');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const manager = new GameManager(io);

app.use(express.json({ limit: '2kb' }));
app.use(express.static(PUBLIC_DIR));

// ---------------------------------------------------------------- REST API
app.get('/api/games', (_req, res) => res.json(manager.listPublic()));

app.post('/api/games', (req, res) => {
  try {
    const game = manager.create(!!(req.body && req.body.public));
    res.json({ code: game.code });
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});

app.get('/api/games/:code', (req, res) => {
  const game = manager.get(req.params.code);
  if (!game) return res.status(404).json({ error: 'Game not found.' });
  res.json({
    code: game.code,
    phase: game.phase,
    joinable: game.phase === 'lobby' && game.players.size < C.MAX_PLAYERS,
  });
});

// the game page is the same HTML for every room code
app.get('/game/:code', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'game.html')));

// ------------------------------------------------------------------ sockets
io.on('connection', (socket) => {
  let current = null; // { game, playerId }

  // run a game action; if it fails, tell only this player why
  const act = (fn) => {
    if (!current) return;
    const result = fn(current.game, current.playerId);
    if (result && result.ok === false) socket.emit('notice', { text: result.error });
  };

  socket.on('join', (data, cb) => {
    const reply = typeof cb === 'function' ? cb : () => {};
    const code = String((data && data.code) || '').toUpperCase().trim();
    const playerId = String((data && data.playerId) || '');
    if (!/^[\w-]{8,64}$/.test(playerId)) return reply({ ok: false, error: 'Invalid player id.' });

    const game = manager.get(code);
    if (!game) return reply({ ok: false, error: 'Game not found. It may have ended.' });

    const result = game.addPlayer(playerId, data && data.name, socket);
    if (!result.ok) return reply(result);
    current = { game, playerId };
    reply({ ok: true });
  });

  socket.on('start', () => act((g, id) => g.startGame(id)));
  socket.on('draft:pick', (d) => act((g, id) => g.draftPick(id, String((d && d.targetId) || ''))));
  socket.on('buzz', () => act((g, id) => g.buzz(id)));
  socket.on('tossup:answer', (d) => act((g, id) => g.answerTossup(id, d && d.text)));
  socket.on('chat', (d) => act((g, id) => g.chat(id, d && d.text)));

  socket.on('disconnect', () => {
    if (current) current.game.disconnect(current.playerId, socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Quizbowl server running on http://localhost:${PORT}`);
});
