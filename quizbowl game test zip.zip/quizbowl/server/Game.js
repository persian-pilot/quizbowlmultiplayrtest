'use strict';
const C = require('./config');
const { pickTossups, pickBonuses } = require('./questions');
const { isCorrect } = require('./answerCheck');

const other = (t) => 1 - t;

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const clean = (s, max) =>
  String(s ?? '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);

const fail = (error) => ({ ok: false, error });
const OK = { ok: true };

/**
 * One quizbowl match.
 * phase: lobby -> draft -> tossup <-> bonus -> finished
 */
class Game {
  constructor(code, isPublic, io) {
    this.code = code;
    this.isPublic = !!isPublic;
    this.io = io;
    this.room = `game:${code}`;

    this.players = new Map(); // playerId -> player
    this.hostId = null;
    this.phase = 'lobby';
    this.captains = [null, null];
    this.scores = [0, 0];
    this.winner = null;

    this.draft = null;
    this.tossups = [];
    this.bonuses = [];
    this.round = 0;
    this.totalRounds = 0;
    this.tu = null; // current tossup state
    this.bn = null; // current bonus state
    this.clock = null; // { kind, deadline, duration } shown to clients

    this.timers = {};
    this.chatLog = [];
    this.msgSeq = 0;

    this.createdAt = Date.now();
    this.emptySince = Date.now();
    this.finishedAt = null;
  }

  // ------------------------------------------------------------------ helpers
  teamRoom(t) { return `${this.room}:t${t}`; }
  teamName(t) { return C.TEAM_NAMES[t]; }
  connectedCount() { return [...this.players.values()].filter((p) => p.connected).length; }
  hostName() { const h = this.players.get(this.hostId); return h ? h.name : '—'; }
  teamPlayers(t) { return [...this.players.values()].filter((p) => p.team === t); }

  setTimer(name, fn, ms) {
    this.clearTimer(name);
    this.timers[name] = setTimeout(() => {
      delete this.timers[name];
      try { fn(); } catch (err) { console.error(`[game ${this.code}] timer ${name} failed:`, err); }
    }, ms);
  }
  clearTimer(name) {
    if (this.timers[name]) { clearTimeout(this.timers[name]); delete this.timers[name]; }
  }
  setClock(kind, ms) { this.clock = { kind, deadline: Date.now() + ms, duration: ms }; }

  destroy() {
    Object.keys(this.timers).forEach((n) => this.clearTimer(n));
    this.players.forEach((p) => p.graceTimer && clearTimeout(p.graceTimer));
  }

  emitTo(playerId, ev, data) {
    const p = this.players.get(playerId);
    if (p && p.connected) this.io.to(p.socketId).emit(ev, data);
  }
  notify(playerId, text) { this.emitTo(playerId, 'notice', { text }); }
  broadcast() { this.io.to(this.room).emit('state', this.publicState()); }

  joinTeamRoom(p) {
    if (p.team === null) return;
    const sock = this.io.sockets.sockets.get(p.socketId);
    if (sock) sock.join(this.teamRoom(p.team));
  }

  effectiveCaptain(team) {
    const cap = this.players.get(this.captains[team]);
    if (cap && cap.connected) return cap.id;
    const stand = this.teamPlayers(team).find((p) => p.connected);
    return stand ? stand.id : this.captains[team];
  }

  // --------------------------------------------------------------------- chat
  pushChat(msg) {
    msg.id = ++this.msgSeq;
    msg.ts = Date.now();
    this.chatLog.push(msg);
    if (this.chatLog.length > 150) this.chatLog.shift();
    if (msg.channel === 'team') this.io.to(this.teamRoom(msg.team)).emit('chat:msg', msg);
    else this.io.to(this.room).emit('chat:msg', msg);
  }
  system(text) { this.pushChat({ kind: 'system', channel: 'all', team: null, name: '', text }); }

  historyFor(p) {
    return this.chatLog.filter((m) => m.channel === 'all' || (m.channel === 'team' && m.team === p.team));
  }

  chat(playerId, rawText) {
    const p = this.players.get(playerId);
    if (!p) return fail('Not in this game.');
    const text = clean(rawText, 300);
    if (!text) return OK;

    const now = Date.now();
    p.chatTimes = (p.chatTimes || []).filter((t) => now - t < 4000);
    if (p.chatTimes.length >= 6) return fail('Slow down!');
    p.chatTimes.push(now);

    if (this.phase === 'tossup') return fail('Team chat is locked during tossups — no conferring!');
    if (this.phase === 'bonus') return this.bonusChat(p, text);

    // lobby / draft / finished: everyone can talk
    this.pushChat({ kind: 'chat', channel: 'all', team: p.team, from: p.id, name: p.name, text });
    return OK;
  }

  bonusChat(p, text) {
    const bn = this.bn;
    if (!bn) return fail('No bonus is active.');
    if (p.team !== bn.team) return fail('Chat is locked while the other team has the bonus.');
    if (bn.status !== 'conferring') return fail('Chat is closed between bonus parts.');

    const m = text.match(/^answer\s*:\s*(.*)$/i);
    if (m) {
      const capId = this.effectiveCaptain(bn.team);
      if (p.id !== capId) {
        const cap = this.players.get(capId);
        return fail(`Only your captain (${cap ? cap.name : '?'}) can give the answer.`);
      }
      const ans = clean(m[1], 80);
      if (!ans) return fail('Put your answer after "Answer:"  e.g.  Answer: Paris');
      this.pushChat({ kind: 'answer', channel: 'team', team: p.team, from: p.id, name: p.name, text: `Answer: ${ans}` });
      this.resolveBonus(ans);
      return OK;
    }
    this.pushChat({ kind: 'chat', channel: 'team', team: p.team, from: p.id, name: p.name, text });
    return OK;
  }

  // ------------------------------------------------------------ join / leave
  addPlayer(playerId, rawName, socket) {
    let p = this.players.get(playerId);
    if (p) {
      const wasAway = !p.connected;
      p.socketId = socket.id;
      p.connected = true;
      if (p.graceTimer) { clearTimeout(p.graceTimer); p.graceTimer = null; }
      if (wasAway) this.system(`${p.name} reconnected.`);
    } else {
      if (this.phase !== 'lobby') return fail('This game has already started.');
      if (this.players.size >= C.MAX_PLAYERS) return fail('This game is full.');
      const base = clean(rawName, 16) || 'Player';
      let name = base;
      let n = 2;
      const taken = (nm) => [...this.players.values()].some((x) => x.name.toLowerCase() === nm.toLowerCase());
      while (taken(name)) name = `${base.slice(0, 13)} ${n++}`;
      p = { id: playerId, name, team: null, connected: true, socketId: socket.id, score: 0, graceTimer: null, chatTimes: [] };
      this.players.set(playerId, p);
      if (!this.hostId) this.hostId = playerId;
      this.system(`${p.name} joined the game.`);
    }
    this.emptySince = null;
    socket.join(this.room);
    this.joinTeamRoom(p);
    socket.emit('chat:history', this.historyFor(p));
    this.broadcast();
    return { ok: true };
  }

  disconnect(playerId, socketId) {
    const p = this.players.get(playerId);
    if (!p || p.socketId !== socketId) return; // stale socket (player reconnected elsewhere)
    p.connected = false;
    if (this.phase === 'lobby') {
      p.graceTimer = setTimeout(() => this.removePlayer(playerId), C.LOBBY_GRACE_MS);
    }
    if (this.hostId === playerId) this.reassignHost();
    if (this.connectedCount() === 0) this.emptySince = Date.now();
    this.broadcast();
  }

  removePlayer(playerId) {
    const p = this.players.get(playerId);
    if (!p || this.phase !== 'lobby' || p.connected) return;
    this.players.delete(playerId);
    this.system(`${p.name} left.`);
    if (this.hostId === playerId) this.reassignHost();
    this.broadcast();
  }

  reassignHost() {
    const next = [...this.players.values()].find((p) => p.connected);
    if (next) this.hostId = next.id;
  }

  // -------------------------------------------------------------- start/draft
  startGame(playerId) {
    if (playerId !== this.hostId) return fail('Only the host can start the game.');
    if (this.phase !== 'lobby') return fail('The game has already started.');
    const here = [...this.players.values()].filter((p) => p.connected);
    if (here.length < C.MIN_PLAYERS) return fail(`Need at least ${C.MIN_PLAYERS} players to start.`);

    // drop anyone who is mid-disconnect
    for (const p of [...this.players.values()]) {
      if (!p.connected) { clearTimeout(p.graceTimer); this.players.delete(p.id); }
    }

    const [c0, c1] = shuffle([...this.players.values()]);
    this.captains = [c0.id, c1.id];
    c0.team = 0; c1.team = 1;
    this.joinTeamRoom(c0); this.joinTeamRoom(c1);

    this.phase = 'draft';
    this.draft = { turnTeam: 0, lastTeam: null, done: false };
    this.system(`Captains chosen at random: ${c0.name} leads ${this.teamName(0)}, ${c1.name} leads ${this.teamName(1)}.`);
    this.system(`${this.teamName(0)} picks first. Captains: choose your teammates!`);
    this.nextDraftTurn(true);
    return OK;
  }

  nextDraftTurn(first) {
    const pool = [...this.players.values()].filter((p) => p.team === null);
    if (pool.length === 0) {
      this.draft.done = true;
      this.draft.turnTeam = null;
      this.clock = null;
      this.clearTimer('draft');
      this.system('Teams are set! The game is about to begin.');
      this.broadcast();
      this.setTimer('phase', () => this.startMatch(), 2500);
      return;
    }
    let team = first ? 0 : other(this.draft.lastTeam);
    if (this.teamPlayers(team).length >= C.TEAM_SIZE) team = other(team);
    this.draft.turnTeam = team;
    this.setClock('draft', C.DRAFT_PICK_MS);
    this.broadcast();
    this.setTimer('draft', () => this.autoPick(), C.DRAFT_PICK_MS);
  }

  assign(target, team) {
    target.team = team;
    this.joinTeamRoom(target);
    this.draft.lastTeam = team;
  }

  draftPick(playerId, targetId) {
    if (this.phase !== 'draft' || !this.draft || this.draft.done) return fail('Not drafting right now.');
    const p = this.players.get(playerId);
    const turn = this.draft.turnTeam;
    if (!p || p.team !== turn || this.captains[turn] !== playerId) return fail("It's not your pick.");
    const target = this.players.get(targetId);
    if (!target || target.team !== null) return fail('That player is not available.');
    this.clearTimer('draft');
    this.assign(target, turn);
    this.system(`${p.name} picks ${target.name} for ${this.teamName(turn)}.`);
    this.nextDraftTurn(false);
    return OK;
  }

  autoPick() {
    if (this.phase !== 'draft' || !this.draft || this.draft.done) return;
    const pool = [...this.players.values()].filter((p) => p.team === null);
    if (!pool.length) return;
    const target = pool[Math.floor(Math.random() * pool.length)];
    const turn = this.draft.turnTeam;
    this.assign(target, turn);
    this.system(`Time's up — ${target.name} is auto-picked for ${this.teamName(turn)}.`);
    this.nextDraftTurn(false);
  }

  startMatch() {
    this.tossups = pickTossups(C.ROUNDS);
    this.bonuses = pickBonuses(C.ROUNDS);
    this.totalRounds = this.tossups.length;
    this.round = 0;
    this.nextTossup();
  }

  // ------------------------------------------------------------------ tossups
  nextTossup() {
    if (this.round >= this.totalRounds) return this.finish();
    const q = this.tossups[this.round];
    this.round++;
    this.phase = 'tossup';
    this.bn = null;
    this.clock = null;
    this.tu = {
      number: this.round,
      q,
      words: q.text.split(/\s+/),
      shown: 0,
      status: 'reading', // reading | open | answering | reveal
      buzzer: null,
      interrupt: false,
      lockedOut: new Set(),
      result: null,
    };
    this.system(`— Tossup ${this.round} of ${this.totalRounds} (${q.category}) — team chat is locked.`);
    this.broadcast();
    this.setTimer('read', () => this.readWord(), C.START_DELAY_MS);
  }

  tuText() { return this.tu.words.slice(0, this.tu.shown).join(' '); }

  readWord() {
    const tu = this.tu;
    if (!tu || tu.status !== 'reading') return;
    if (tu.shown < tu.words.length) {
      tu.shown++;
      this.io.to(this.room).emit('tossup:text', { number: tu.number, text: this.tuText() });
    }
    if (tu.shown >= tu.words.length) this.openWindow();
    else this.setTimer('read', () => this.readWord(), C.WORD_MS);
  }

  // question fully read: players get a last window to buzz
  openWindow() {
    const tu = this.tu;
    tu.status = 'open';
    this.setClock('open', C.POSTREAD_MS);
    this.broadcast();
    this.setTimer('read', () => this.revealTossup(null), C.POSTREAD_MS);
  }

  buzz(playerId) {
    const tu = this.tu;
    const p = this.players.get(playerId);
    if (this.phase !== 'tossup' || !tu || !p) return fail('You can’t buzz right now.');
    if (p.team === null) return fail('Only team players can buzz.');
    if (tu.status !== 'reading' && tu.status !== 'open') return fail('Too late — someone already buzzed.');
    if (tu.lockedOut.has(playerId)) return fail('You are locked out of this tossup.');

    this.clearTimer('read');
    tu.interrupt = tu.shown < tu.words.length;
    tu.status = 'answering';
    tu.buzzer = playerId;
    this.setClock('answer', C.ANSWER_MS);
    this.system(`${p.name} (${this.teamName(p.team)}) buzzed in!`);
    this.broadcast();
    this.setTimer('answer', () => this.resolveTossupAnswer(p, '', true), C.ANSWER_MS);
    return OK;
  }

  answerTossup(playerId, rawText) {
    const tu = this.tu;
    const p = this.players.get(playerId);
    if (this.phase !== 'tossup' || !tu || !p || tu.status !== 'answering' || tu.buzzer !== playerId) {
      return fail('You are not the one answering.');
    }
    this.resolveTossupAnswer(p, clean(rawText, 80), false);
    return OK;
  }

  resolveTossupAnswer(p, text, timedOut) {
    const tu = this.tu;
    if (!tu || tu.status !== 'answering') return;
    this.clearTimer('answer');
    this.clock = null;
    tu.buzzer = null;
    const correct = !timedOut && isCorrect(text, tu.q);

    if (correct) {
      p.score += C.TOSSUP_POINTS;
      this.scores[p.team] += C.TOSSUP_POINTS;
      this.system(`${p.name} answered "${text}" — correct! +${C.TOSSUP_POINTS} for ${this.teamName(p.team)}.`);
      return this.revealTossup({ correct: true, playerId: p.id, team: p.team, delta: C.TOSSUP_POINTS });
    }

    let delta = 0;
    if (tu.interrupt) {
      delta = C.NEG_POINTS;
      p.score += delta;
      this.scores[p.team] += delta;
    }
    tu.lockedOut.add(p.id);
    const tail = delta ? ` (${delta})` : '';
    this.system(timedOut ? `${p.name} ran out of time${tail}.` : `${p.name} answered "${text}" — incorrect${tail}.`);

    const eligible = [...this.players.values()].filter((x) => x.team !== null && !tu.lockedOut.has(x.id));
    if (eligible.length === 0) return this.revealTossup(null);

    if (tu.shown < tu.words.length) {
      tu.status = 'reading';
      this.broadcast();
      this.setTimer('read', () => this.readWord(), C.RESUME_MS);
    } else {
      this.openWindow();
    }
  }

  revealTossup(result) {
    const tu = this.tu;
    if (!tu || tu.status === 'reveal') return;
    this.clearTimer('read');
    this.clearTimer('answer');
    this.clock = null;
    tu.status = 'reveal';
    tu.result = result;
    tu.shown = tu.words.length;
    tu.buzzer = null;
    this.system(result ? `Answer: ${tu.q.answer}` : `Nobody got it. Answer: ${tu.q.answer}`);
    this.broadcast();
    const winnerTeam = result && result.correct ? result.team : null;
    this.setTimer('next', () => (winnerTeam !== null ? this.startBonus(winnerTeam) : this.nextTossup()), C.REVEAL_MS);
  }

  // ------------------------------------------------------------------ bonuses
  startBonus(team) {
    const set = this.bonuses[(this.round - 1) % this.bonuses.length];
    this.phase = 'bonus';
    this.tu = null;
    this.bn = { team, set, part: 0, status: 'conferring', results: [], lastCorrect: null, lastAnswer: null };
    const cap = this.players.get(this.effectiveCaptain(team));
    this.system(`${this.teamName(team)} earned a bonus (${set.category})! You have ${Math.round(C.BONUS_MS / 1000)}s per part to confer. Captain ${cap ? cap.name : ''}: type  Answer: <your answer>`);
    this.startBonusPart();
  }

  startBonusPart() {
    const bn = this.bn;
    bn.status = 'conferring';
    bn.lastCorrect = null;
    bn.lastAnswer = null;
    this.setClock('bonus', C.BONUS_MS);
    this.system(`Bonus part ${bn.part + 1} of ${bn.set.parts.length} — ${this.teamName(bn.team)} may confer now.`);
    this.broadcast();
    this.setTimer('bonus', () => this.resolveBonus(null), C.BONUS_MS);
  }

  resolveBonus(answerText) {
    const bn = this.bn;
    if (this.phase !== 'bonus' || !bn || bn.status !== 'conferring') return;
    this.clearTimer('bonus');
    this.clock = null;
    const part = bn.set.parts[bn.part];
    const correct = answerText !== null && isCorrect(answerText, part);
    bn.status = 'reveal';
    bn.lastCorrect = correct;
    bn.lastAnswer = answerText;
    bn.results.push(correct);
    if (correct) {
      this.scores[bn.team] += C.BONUS_POINTS;
      this.system(`Correct! +${C.BONUS_POINTS} for ${this.teamName(bn.team)}.`);
    } else if (answerText === null) {
      this.system(`Time's up! The answer was ${part.answer}.`);
    } else {
      this.system(`Incorrect. The answer was ${part.answer}.`);
    }
    this.broadcast();
    this.setTimer('next', () => {
      bn.part++;
      if (bn.part < bn.set.parts.length) this.startBonusPart();
      else this.nextTossup();
    }, C.REVEAL_MS);
  }

  // ------------------------------------------------------------------- finish
  finish() {
    this.phase = 'finished';
    this.tu = null;
    this.bn = null;
    this.clock = null;
    this.finishedAt = Date.now();
    const [a, b] = this.scores;
    this.winner = a === b ? null : a > b ? 0 : 1;
    this.system(
      this.winner === null
        ? `Game over — it's a tie at ${a}–${b}! Chat is open to everyone.`
        : `Game over — ${this.teamName(this.winner)} wins ${Math.max(a, b)}–${Math.min(a, b)}! Chat is open to everyone.`
    );
    this.broadcast();
  }

  // ------------------------------------------------------ what clients can see
  publicState() {
    const tu = this.tu;
    const bn = this.bn;

    const players = [...this.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      team: p.team,
      connected: p.connected,
      score: p.score,
      isHost: p.id === this.hostId,
      isCaptain: p.team !== null && this.captains[p.team] === p.id,
      buzzing: !!(tu && tu.status === 'answering' && tu.buzzer === p.id),
      lockedOut: !!(tu && tu.lockedOut.has(p.id)),
    }));

    let chat = { mode: 'all' };
    if (this.phase === 'tossup') {
      chat = { mode: 'locked', reason: 'Team chat is locked during tossups — no conferring!' };
    } else if (this.phase === 'bonus') {
      chat = bn.status === 'conferring'
        ? { mode: 'team', team: bn.team }
        : { mode: 'locked', reason: 'Chat is closed between bonus parts.' };
    }

    return {
      code: this.code,
      phase: this.phase,
      isPublic: this.isPublic,
      hostId: this.hostId,
      serverTime: Date.now(),
      maxPlayers: C.MAX_PLAYERS,
      minPlayers: C.MIN_PLAYERS,
      teamNames: C.TEAM_NAMES,
      scores: [...this.scores],
      round: this.round,
      totalRounds: this.totalRounds,
      players,
      chat,
      clock: this.clock,
      winner: this.phase === 'finished' ? this.winner : undefined,
      draft: this.phase === 'draft' && this.draft ? { turnTeam: this.draft.turnTeam, done: this.draft.done } : null,
      tossup: tu
        ? {
            number: tu.number,
            category: tu.q.category,
            text: this.tuText(),
            done: tu.shown >= tu.words.length,
            status: tu.status,
            buzzer: tu.buzzer,
            interrupt: tu.interrupt,
            lockedOut: [...tu.lockedOut],
            result: tu.result,
            answer: tu.status === 'reveal' ? tu.q.answer : null,
          }
        : null,
      bonus: bn
        ? {
            team: bn.team,
            category: bn.set.category,
            leadin: bn.set.leadin,
            partIndex: bn.part,
            partCount: bn.set.parts.length,
            prompt: bn.set.parts[bn.part].prompt,
            status: bn.status,
            results: bn.results,
            captainId: this.effectiveCaptain(bn.team),
            lastCorrect: bn.lastCorrect,
            lastAnswer: bn.lastAnswer,
            answer: bn.status === 'reveal' ? bn.set.parts[bn.part].answer : null,
          }
        : null,
    };
  }
}

module.exports = Game;
