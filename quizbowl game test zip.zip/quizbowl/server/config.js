// All the tunable game rules live here.
module.exports = {
  MAX_PLAYERS: 8,
  MIN_PLAYERS: 2, // lower this to 2 so you can test alone with two tabs; set to 8 for "real" games
  TEAM_SIZE: 4,
  ROUNDS: 8, // number of tossups (each correct tossup earns that team a bonus)

  WORD_MS: 260, // ms between words while a tossup is being read
  START_DELAY_MS: 1500, // pause before a tossup starts being read
  RESUME_MS: 1200, // pause before reading resumes after a wrong answer
  POSTREAD_MS: 5000, // buzz window after the tossup finishes being read
  ANSWER_MS: 10000, // time a buzzer has to type a tossup answer
  BONUS_MS: 20000, // team conferring time on each bonus part
  DRAFT_PICK_MS: 20000, // time a captain has to pick before an auto-pick
  REVEAL_MS: 4000, // how long answers stay on screen
  LOBBY_GRACE_MS: 10000, // disconnected lobby players are removed after this

  TOSSUP_POINTS: 10,
  NEG_POINTS: -5, // buzzing before the question finished and being wrong
  BONUS_POINTS: 10,

  TEAM_NAMES: ['Red', 'Blue'],
};
