'use strict';
const C = require('./config');
const Game = require('./Game');

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I
const MAX_GAMES = 500;

class GameManager {
  constructor(io) {
    this.io = io;
    this.games = new Map();
    this.sweeper = setInterval(() => this.sweep(), 60 * 1000);
    this.sweeper.unref();
  }

  newCode() {
    let code;
    do {
      code = Array.from({ length: 5 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
    } while (this.games.has(code));
    return code;
  }

  create(isPublic) {
    if (this.games.size >= MAX_GAMES) throw new Error('Server is busy, try again soon.');
    const game = new Game(this.newCode(), isPublic, this.io);
    this.games.set(game.code, game);
    return game;
  }

  get(code) {
    return this.games.get(String(code || '').toUpperCase().trim());
  }

  // public games that are still open for joining
  listPublic() {
    return [...this.games.values()]
      .filter((g) => g.isPublic && g.phase === 'lobby' && g.players.size < C.MAX_PLAYERS && g.connectedCount() > 0)
      .sort((a, b) => a.createdAt - b.createdAt)
      .map((g) => ({ code: g.code, host: g.hostName(), players: g.connectedCount(), max: C.MAX_PLAYERS }));
  }

  // remove abandoned and long-finished games
  sweep() {
    const now = Date.now();
    for (const [code, g] of this.games) {
      const abandoned = g.emptySince && now - g.emptySince > 2 * 60 * 1000;
      const stale = g.finishedAt && now - g.finishedAt > 15 * 60 * 1000;
      if (abandoned || stale) {
        g.destroy();
        this.games.delete(code);
      }
    }
  }
}

module.exports = GameManager;
