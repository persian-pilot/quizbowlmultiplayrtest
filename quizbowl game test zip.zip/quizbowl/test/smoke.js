// Plays a whole game against the Game class with a fake socket.io — no network needed.
// Run with:  npm test
const assert = require('assert');
const C = require('../server/config');

// shrink the timings so the test finishes in about a second
Object.assign(C, {
  WORD_MS: 3, START_DELAY_MS: 5, RESUME_MS: 5, POSTREAD_MS: 40, ANSWER_MS: 120,
  BONUS_MS: 150, DRAFT_PICK_MS: 60, REVEAL_MS: 10, ROUNDS: 3, MIN_PLAYERS: 2,
});
const Game = require('../server/Game');

const sockets = new Map();
const io = { sockets: { sockets }, to: () => ({ emit() {} }) };
function socket(id) {
  const s = { id, join() {}, emit() {} };
  sockets.set(id, s);
  return s;
}

const waitFor = (cond, label, ms = 4000) =>
  new Promise((resolve, reject) => {
    const t0 = Date.now();
    (function tick() {
      let ok = false;
      try { ok = cond(); } catch { /* keep waiting */ }
      if (ok) return resolve();
      if (Date.now() - t0 > ms) return reject(new Error('timed out waiting for: ' + label));
      setTimeout(tick, 1);
    })();
  });

const must = (res, msg) => assert.ok(res && res.ok, msg + ' -> ' + (res && res.error));
const mustFail = (res, msg) => assert.ok(res && res.ok === false, msg + ' should have failed');

(async () => {
  const g = new Game('TEST1', true, io);
  const ids = Array.from({ length: 8 }, (_, i) => `player-${i}-xxxxxxxx`);
  ids.forEach((id, i) => must(g.addPlayer(id, `P${i}`, socket(`s${i}`)), 'join ' + i));
  mustFail(g.addPlayer('player-9-xxxxxxxx', 'Extra', socket('s9')), 'a 9th player joining');

  // --- start + draft
  mustFail(g.startGame(ids[3]), 'non-host starting');
  must(g.startGame(ids[0]), 'host starting');
  assert.equal(g.phase, 'draft');
  const caps = [...g.players.values()].filter((p) => p.team !== null);
  assert.equal(caps.length, 2, 'two captains');
  assert.notEqual(caps[0].team, caps[1].team);

  const pickersTurn = () => g.players.get(g.captains[g.draft.turnTeam]);
  let picks = 0;
  while (g.phase === 'draft' && !g.draft.done && picks < 3) {
    const cap = pickersTurn();
    const target = [...g.players.values()].find((p) => p.team === null);
    mustFail(g.draftPick(target.id, cap.id), 'non-captain picking'); // wrong direction on purpose
    must(g.draftPick(cap.id, target.id), 'captain pick');
    picks++;
  }
  // let the timer auto-pick the rest
  await waitFor(() => g.phase === 'tossup', 'draft to finish');
  const t0 = g.teamPlayers(0), t1 = g.teamPlayers(1);
  assert.equal(t0.length, 4); assert.equal(t1.length, 4);

  // nobody new can join once started, but existing players can reconnect
  mustFail(g.addPlayer('late-joiner-xxxxxx', 'Late', socket('late')), 'late joiner');
  must(g.addPlayer(ids[1], 'ignored', socket('s1b')), 'reconnect');

  // --- Tossup 1: early wrong buzz (neg), then the other team gets it
  await waitFor(() => g.tu && g.tu.status === 'reading' && g.tu.shown > 2, 'tossup 1 reading');
  assert.equal(g.publicState().tossup.answer, null, 'answer must stay hidden');
  mustFail(g.chat(t0[1].id, 'psst the answer is...'), 'tossup chat');
  must(g.buzz(t0[0].id), 'buzz');
  mustFail(g.buzz(t1[0].id), 'second buzz while answering');
  must(g.answerTossup(t0[0].id, 'definitely not it'), 'wrong answer');
  assert.equal(g.scores[0], -5, 'neg applied');
  mustFail(g.buzz(t0[0].id), 'locked-out player re-buzzing');
  await waitFor(() => g.tu.status === 'reading' || g.tu.status === 'open', 'reading resumes');
  must(g.buzz(t1[0].id), 'other team buzz');
  must(g.answerTossup(t1[0].id, g.tu.q.answer.toLowerCase()), 'correct answer (case-insensitive)');
  assert.equal(g.scores[1], 10);

  // --- Bonus for team 1
  await waitFor(() => g.phase === 'bonus', 'bonus starts');
  assert.equal(g.bn.team, 1);
  const cap1 = g.players.get(g.captains[1]);
  const mate = t1.find((p) => p.id !== cap1.id);
  must(g.chat(mate.id, 'I think it is Paris?'), 'team chat during bonus');
  mustFail(g.chat(t0[0].id, 'hello from the other team'), 'other team chatting during bonus');
  mustFail(g.chat(mate.id, 'Answer: whatever'), 'non-captain answering');
  assert.equal(g.bn.part, 0);
  const parts = g.bn.set.parts;
  must(g.chat(cap1.id, 'Answer: ' + parts[0].answer), 'captain answer part 1');
  assert.equal(g.scores[1], 20);
  await waitFor(() => g.bn.part === 1 && g.bn.status === 'conferring', 'part 2 starts');
  // part 2: let it time out
  await waitFor(() => g.bn.part === 2 && g.bn.status === 'conferring', 'part 3 starts (after timeout)');
  must(g.chat(cap1.id, 'answer:   ' + parts[2].answer), 'captain answer part 3 (case/space tolerant)');
  assert.equal(g.scores[1], 30);
  assert.deepEqual(g.bn.results, [true, false, true]);

  // --- Tossup 2: buzz after the question is read, then time out (no neg)
  await waitFor(() => g.phase === 'tossup' && g.tu.status === 'open', 'tossup 2 open window');
  const before = g.scores[0];
  must(g.buzz(t0[2].id), 'late buzz');
  await waitFor(() => g.tu.status !== 'answering', 'answer timer expiry');
  assert.equal(g.scores[0], before, 'no neg for a post-read miss');

  // --- Tossup 3: nobody buzzes; game finishes
  await waitFor(() => g.phase === 'finished', 'game to finish', 8000);
  assert.equal(g.winner, 1);
  assert.equal(g.chat(t0[0].id, 'gg').ok, true, 'chat reopens after the game');

  g.destroy();
  console.log('✔ All smoke tests passed. Final score:', g.scores.join(' - '));
  process.exit(0);
})().catch((err) => {
  console.error('✘ FAILED:', err.message);
  process.exit(1);
});
