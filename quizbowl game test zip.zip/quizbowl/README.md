# 🧠 Quizbowl Arena

Multiplayer quizbowl in the browser: 2 teams, random captains who draft their teammates, then tossups and bonuses with a live animated table and a rules-enforcing chat.

## Run it

```bash
npm install
npm start          # http://localhost:3000
npm test           # plays a full game against the server logic (no browser needed)
```

Needs Node 18+. To try it alone, open the site in 2+ **separate tabs** — each tab is its own player. Close/reopen a tab and you become a new player; refreshing keeps you in the game.

## How a game flows

1. **Lobby** – create a public game (shows on the home page list) or a private one (share the link `/game/ABCDE`). Up to 8 players. The first player is the host.
2. **Start** – host clicks Start. After that **no one new can join** (people already in can reconnect).
3. **Draft** – two captains are chosen at random. Captains alternate picking teammates (20s per pick, then auto-pick). Teams of 4.
4. **Tossup** – question is read word by word. **Anyone can buzz** (button or Space). The buzzer has **10s** to type an answer. Team chat is **locked** — no conferring.
   - Correct: +10 and the team gets a bonus.
   - Wrong after buzzing *before the question finished*: −5 (neg). Wrong player is locked out; others can keep buzzing.
5. **Bonus** – 3 parts. The team that won the tossup gets **20s per part** to confer in **team chat** (the other team's chat is locked). The **captain** (picked at the start) types `Answer: their answer` — first `Answer:` counts. Only the captain can answer; if the captain is disconnected, a connected teammate stands in. 10 points per part.
6. After 8 rounds the higher score wins and chat opens to everyone.

## Files

```
server/
  index.js         Express + Socket.IO server, REST endpoints, socket event wiring
  GameManager.js   Creates/finds games, lists public ones, cleans up abandoned ones
  Game.js          ALL the game logic: lobby, draft, tossups, bonuses, chat rules, timers
  questions.js     Placeholder tossups + bonuses  <-- replace with real questions
  answerCheck.js   Forgiving answer matching (case, punctuation, a/an/the, small typos)
  config.js        Timings, points, team sizes, rounds

public/
  index.html       Home: create / join by code / public game list
  game.html        The game page (table, panels, chat)
  css/style.css    Styling + table animations
  js/common.js     Small helpers (player id, DOM builder, toast)
  js/lobby.js      Home page logic
  js/game.js       Socket connection + rendering of every game phase
  js/table.js      Animated table (seats glide to their team side, buzz pulse, +10/−5 floaters)
  js/chat.js       Chat panel

test/smoke.js      Full-game simulation
Dockerfile         Optional container build
```

## Customizing

- **Questions:** edit `server/questions.js`. Tossup = `{category, text, answer, accept: []}`; bonus = `{category, leadin, parts:[{prompt, answer, accept}]}`.
- **Rules/timings:** `server/config.js` (`MIN_PLAYERS` is 2 so you can test alone; set it to 8 for strict full-table games).
- **Team names/colors:** `TEAM_NAMES` in config, `--red` / `--blue` in `style.css`.

## Socket events

| Client → server | Meaning |
|---|---|
| `join {code, playerId, name}` | enter a room (ack `{ok, error}`) |
| `start` | host starts the game |
| `draft:pick {targetId}` | captain drafts a player |
| `buzz` | buzz on a tossup |
| `tossup:answer {text}` | the buzzer's answer |
| `chat {text}` | chat; server decides channel (all / team / locked) and parses `Answer:` |

| Server → client | Meaning |
|---|---|
| `state` | full public game state (never includes unrevealed answers) |
| `tossup:text` | the tossup text as it is read |
| `chat:history`, `chat:msg` | chat log / new message |
| `notice` | private message to one player (e.g. "chat is locked") |

## Notes / next steps

- Everything is in memory — restarting the server ends all games. Add Redis/a DB if you want persistence.
- There are no accounts; identity is a random id per browser tab. Fine for friends, not for competitive play.
- Ideas: rematch button, spectators, scoreboard stats, question packets from a database, host-selectable settings.
